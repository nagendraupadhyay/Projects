#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

class isprime 
{
    public:
        isprime() {plist.push_back(2);}
        bool operator()(int);
    private:
	    void expand_plist(int);
        vector<int> plist;
};

bool isprime::operator()(int number)
{
    vector<int>::iterator pnumber;

    if(number <= plist[plist.size() - 1])
    {
        pnumber = find(plist.begin(), plist.end(), number);
    }

    if(number > plist[plist.size() - 1])
    {
        expand_plist(number);
        pnumber = find(plist.begin(), plist.end(), number);
    }

    if(pnumber == plist.end())
    {
        return false;
    }
    else
    {
        return true;
    }
}

void isprime::expand_plist(int number)
{
    int E = plist[plist.size() - 1] + 1;
    bool primeN = true;
    
    while(plist.back()<number)
    {
        for(int j = 2; j < sqrt(E); j++)
        {
            if(E%j == 0)
            {
                primeN = false;
            }
        }
        if(primeN == true)
        {
            plist.push_back(E);
        }
        primeN = true;
        E++;
    }
}

int main()
{
  isprime pcheck;
  int number;

  while (cin>>number) {
    if (pcheck(number))
    {
        cout << number << " is a prime number" << endl;
    }
  }
}
