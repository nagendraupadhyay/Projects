#ifndef BST_H
#define BST_H

#include <iomanip>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

template <class TKey>
class bst {
  
    struct node {
	    node(int n_ID=0); //node constructor (see below)

		void print(); //print function (TKey version partially written for you, will need to write special string version)

		TKey key; //key of a bst node
		int ID; //id of a bst node

		node *parent; //parent of bst node
		node *link[2]; //you must use link array! link[0] = left child, link[1] = right child
	};

 /* public:
    class iterator {
        public:
            iterator();
            iterator &operator++();
            TKey &operator*();
            bool operator==(const iterator &rhs) const;

        private:
            friend class bst<TKey>;
            iterator(node *new_p);

         node *p;
    };*/

    //iterator begin();
    //iterator end();

  public:
    bst() { Troot=NULL; nodeID = 0;}
    ~bst() { clear(Troot); }

    bool empty() { return Troot==NULL; }

    void insert(const TKey &);

    //iterator lower_bound(const TKey &);
    //iterator upper_bound(const TKey &);

    void print_bylevel();

  private:

    void clear(node *);
    node *insert(node *, const TKey &);

    int nodeID;
    node *Troot;
};

//bst<TKey>::node constructor goes here
template <typename TKey>
bst<TKey>::node::node(int n_ID)
{
    ID = n_ID;
    parent = NULL;
    link[0] = NULL;
    link[1] = NULL;
}

template <class TKey>
void bst<TKey>::node::print()
{
    cout << setw(3) << ID << " ";
    cout << setw(3) << key << " :";
    
    if(parent)
    {
        cout << " P=" << setw(3) << parent->ID  << " ";
    }
    else{cout << setw(3) << " ROOT  ";}
    
    if (link[0]) cout << " L=" << setw(3) << link[0]->ID;
    else         cout << "      ";
    if (link[1]) cout << " R=" << setw(3) << link[1]->ID;
    else         cout << "      ";

    cout << "\n";
}

template <>
void bst<string>::node::print()
{
    cout << setw(20) << ID << " ";
    cout << setw(20) << key << " :";
    if(parent)
    {
        cout << " P=" << setw(20) << parent->ID << " ";
    }
    else{cout << setw(3) << " ROOT  ";}

    if (link[0]) cout << " L=" << setw(3) << link[0]->ID;
    else         cout << "      ";
    if (link[1]) cout << " R=" << setw(3) << link[1]->ID;
    else         cout << "      ";   
    cout << "\n";
}

//bst<TKey>::iterator functions not defined above go here

template <class TKey>
void bst<TKey>::clear(node *T)
{
    if (T) {
        clear(T->link[0]);
        clear(T->link[1]);
        delete T;
        T = NULL;
    }
}

template <class TKey>
void bst<TKey>::insert(const TKey &key)
{ 
    Troot = insert(Troot, key);
    if(Troot)
        Troot->parent = NULL;
}

template <class TKey>
struct bst<TKey>::node *bst<TKey>::insert(node *T,const TKey &key)
{
    if (T == NULL) {
      //  update and set node ID
        T = new node;
        T->key = key;
        T->ID = ++nodeID;
    } else if (T->key == key) {
        ;
    } else if (key < T->key) {
        T->link[0] = insert(T->link[0], key);
        T->link[0]->parent = T;
    } else {
        T->link[1] = insert(T->link[1], key);
        T->link[1]->parent = T;
    }

    return T;
}

//bst<TKey>::lower_bound function goes here

//bst<TKey>::upper_bound function goes here

template <class TKey>
void bst<TKey>::print_bylevel()
{
  if (Troot == NULL)
    return;

  queue<node *> Q;
  node *T;

  Q.push(Troot);
  while (!Q.empty()) {
    T = Q.front();
    Q.pop();

    T->print();
    if (T->link[0]) Q.push(T->link[0]);
    if (T->link[1]) Q.push(T->link[1]);
  }
}
#endif
