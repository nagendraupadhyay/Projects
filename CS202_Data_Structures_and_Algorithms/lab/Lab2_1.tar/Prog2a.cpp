#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

const string face[] = { "Ace", "2", "3", "4", "5", "6", "7",
                        "8", "9", "10", "Jack", "Queen", "King" }; 
const string suit[] = { "Diamonds", "Hearts", "Clubs", "Spades" };

string random_card(bool verbose=false) 
{
	string card;

    card = face[ rand()%13 ];
	card += " of ";
	card += suit[ rand()%4 ];

	if (verbose)
	  cout << card << "\n";

	return card;
}

int main(int argc, char *argv[])
{
	bool verbose = false;
	int seedvalue = 0;
    //Strings made to help compare the string to the cards drawn.
    string store_suit;
    string store_face;

	for (int i=1; i<argc; i++) 
    {
	    string option = argv[i];
	    if (option.compare(0,6,"-seed=") == 0) 
        {
	        seedvalue = atoi(&argv[i][6]);
	    } 
        else if (option.compare("-verbose") == 0) 
        {
	        verbose = true;
	    } 
        else
        { 
	        cout << "option " << argv[i] << " ignored\n";
        }
	}
    srand(seedvalue);
    
    //Making a table to store the data of the cards. Made a boolean so it can check if any of the suit has finished getting all 13 cards.
    int count[4][13] = {0};
    int N = 0;
    int M = 0;
    int i;
    int j;
    bool keepDealing = true;

	while (keepDealing) 
    {
	    //Code for storing data in strings for the random cards drawn from the deck.
        string card = random_card(verbose);
	    stringstream storingData(card);
        storingData >> store_face >> store_suit >> store_suit;
        
        //This for loop goes through all 13 cards of each and ever suit.
        for(i = 0; i < 13; i++)
        {
            //This if statement compares the cards drawn and also stores the no. of times it got the same card.
            if(face[i] == store_face)
            {
                N = i;
                break;
            }
        }
        //loop goes 4 times and compares each suit of the card and stores the no. of the same cards drawn.
        for(j = 0; j < 4; j++)
        {
            if(suit[j] == store_suit)
            {
                M = j;
                break;
            }
        }
        
        //Declaring a table and setting the boolean equal to false so it can help while loop stop if needed.
        //Updating the table every time a card is drawn.
        count[M][N]++;
        keepDealing = false;

        //The loop below checks if any of the 13 places in a row has a zero. If so then it keeps running.
        for (i=0; i < 13; i++)
        {
            if(count[M][i] == 0)
            {
                keepDealing = true;
            }
        }
	}

    //Loop made to ouput the data stored in the table.
    for(j = 0; j < 4; j++)
    {
        cout << setw(8) << suit[j] << " : ";
        for(i = 0; i < 13; i++)
        {
            cout << "   " << count[j][i];
        }
        if(j == M)
        {
            cout << " **";
        }
        cout << endl;
    }
}
