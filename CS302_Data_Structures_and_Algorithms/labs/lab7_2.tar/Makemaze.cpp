//Nagendra Upadhyay. This lab is a maze creater and solution finder. The code below makes a random maze.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//The class below is taken from a handout and is used to help munipulate cells.
class dset{
    struct node {
    node() {rank = 0, parent = -1;}
    int rank;
    int parent;
  };
  public:
    dset(int Nsets);
    ~dset();
    int size() { return Nsets; }
    int merge(int, int);
    int find(int);
  private:
    int Nsets;
    node *S;
};

//Below is a contructor which makes size for all the cells.
dset::dset(int N) { 
    S = new node[N];
    Nsets = N;
}

//A destructor to delete S memory.
dset::~dset(){
    delete S;
}

//The below two functions are for disjoint set
int dset::merge(int i, int j) {
    i = find(i);
    j = find(j);
    if (i != j) {
        node &Si = S[i];
        node &Sj = S[j];
        // merge (union) by rank
        if (Si.rank > Sj.rank)      Sj.parent = i;
        else if (Si.rank < Sj.rank) Si.parent = j;
        else { Sj.parent = i; Si.rank += 1; }
        Nsets -= 1;
    }
    return find(i);
}

int dset::find(int i) {
    if (S[i].parent == -1)
        return i;
    // recursive path compression
    S[i].parent = find(S[i].parent);
    return S[i].parent;
}

//constructors as needed
struct cell { int i = 0, j = 0;};
struct cell_pair { cell c1, c2;};

//Below is a swap function to swap two things
void swap(cell_pair &x, cell_pair &y){
    cell_pair temp = x;
    x = y;
    y = temp;
}

int main(int argc, char *argv[]){
    //command line arguments
    int Nrows;
    int Ncols;
    char *inputfile;

    if(argc == 4){
        //Below the command lines are taking in size of the maze and name of the life they want to put it in
        Nrows = atoi(argv[1]);
        Ncols = atoi(argv[2]);
        inputfile = argv[3];
    }
    
    // below (i+1,j) and to the right (i,j+1) while 
    
    //Find the total size of the maze and makes space for them
    int Ncells = Nrows * Ncols;
    cell_pair adjlist[2*Ncells];
    
    //The variables below are to help with munipulation
    cell c1;
    cell c2;
    int counter = 0;
    srand(time(NULL));
    
    //The for loops below are creating list of cells (i,j) and their neighbors 
    for(int m = 0; m < Nrows; m++){
        for(int n = 0; n < Ncols; n++){
            c1.i = m;
            c1.j = n;

            //Checking to exclude things other the grid
            if(m + 1 < Nrows){
                //below the cells check down for (m+1,n) and to the right (i,j+1) and making connnections
                c2.i = m + 1;
                c2.j = n;
                
                //populate adjlist[]: with cell(i,j)
                adjlist[counter].c1  = c1;
                adjlist[counter].c2 = c2;
                counter++;
            }
            
            //Checking to exclude things other the grid
            if(n + 1 < Ncols){
                //below the cells check down for (m+1,n) and to the right (i,j+1) and making connnections
                c2.j = n + 1;
                c2.i = m;

                //populatinge adjlist[]: with cell(i,j)
                adjlist[counter].c1 = c1;
                adjlist[counter].c2 = c2;
                counter++;
            }
        }
    }
    

    for(int i = 0; i < counter - 1; i++){
        //randomizing the maze contents to make a different make everytime
        swap(adjlist[i], adjlist[i + rand() % (counter - i)]);
    }

    //writing maze header to file
    FILE *fp;
    fp = fopen(inputfile, "w");
    fprintf(fp, "%s", "MAZE ");
    fprintf(fp, "%i %i\n", Nrows, Ncols);
    
    dset DS(Ncells);
    int k = 0;
    while (1 < DS.size()) {
	    //setting next cell pair: (c1,c2) = adjlist[k]
        int i = adjlist[k].c1.i;
        int j = adjlist[k].c1.j;
        int m = adjlist[k].c2.i;
        int n = adjlist[k].c2.j;
        int c1 = i * Ncols + j;
        int c2 = m * Ncols + n;
        
        //While two cells are not in the same set enters this if statement
        if(DS.find(c1) != DS.find(c2)){
            //As the cells are not in the same sets, merging the two sets below
            DS.merge(c1, c2);
            //Printing the cell indices to the maze file
            fprintf(fp, "%3d ", i);
            fprintf(fp, "%3d ", j);
            fprintf(fp, "%3d ", m);
            fprintf(fp, "%3d ", n);
            fprintf(fp, "\n");
        }

        k++;
    }
}
