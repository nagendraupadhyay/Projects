//Nagendra Upadhyay. The code below takes in the file that made the random maze and finds a path/solution for it.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

//adding constructor as needed
struct cell { 
    int i = 0; 
    int j = 0; 
    
    cell(int x, int y){
        i = x;
        j = y;
    }
    cell(){};
};

int main(int argc, char *argv[]) {
    //command line arguments
    int Nrows;
    int Ncols;
    char *Mputfile;
    char *Poutfile;

    //The if loop below takes in the names of the files and stores them
    if(argc == 3){
         Mputfile = argv[1];
         Poutfile = argv[2];
    }

    //Opening and reading the maze file below to start extracting data
    FILE *fp;
    fp = fopen(Mputfile, "r");
    
    if(!fp){
        printf("File did not read\n");
        exit(1);
    }
    
    //Saving the number of rows and cols for the maze
    fscanf(fp, "MAZE %i %i", &Nrows, &Ncols);

    //making bool pointer to start making space in the adjtable/
    bool ***adjtable;
    adjtable = new bool**[Nrows];
    
    if(adjtable == NULL){
        printf("Memory was not allocated");
        exit(0);
    }

    //creating 3D adjacency table to allocate memory to access
    for(int i = 0; i < Nrows; i++){
        adjtable[i] = new bool*[Ncols];
        for(int j = 0; j < Ncols; j++){
            adjtable[i][j] = new bool[4];
            for(int k = 0; k < 4; k++){
                //setting all the cell values to be false as walls default
                adjtable[i][j][k] = false;
            }
        }
    }

    int i1, j2, i3, j4;
    //The while loops below reads cell pairs (c1,c2) from maze file and updates adjtable to create lines or spaces
    while(fscanf(fp,"%d %d %d %d",&i1,&j2,&i3,&j4) == 4){
        //The if statements below goes through all cells and finds out if there has a wall or opening.
        if(i1==i3){
            if(j4-j2 == 1){
                adjtable[i1][j2][3] = true;//right
                adjtable[i3][j4][2] = true;//left
            }
        }
        if(j2==j4){
            if(i3-i1 == 1){
                adjtable[i1][j2][1] = true;//up
                adjtable[i3][j4][0] = true;//down
            }
        }
    }
    
    //closing the maze file as all the needed data is stored
    fclose(fp);
    
    cell source(0,0);
    cell sink(Nrows-1, Ncols-1);
    enum color_t { WHITE, BLACK };
    color_t **vcolor;
    cell **link;

    //allocating memory for 2D vcolor and link arrays, 
    vcolor = new color_t*[Nrows];
    link = new cell*[Nrows];

    for(int i = 0; i < Nrows; i++){
        vcolor[i] = new color_t[Ncols];
        link[i] = new cell[Ncols];
        for(int j = 0; j < Ncols; j++){
            //marking all cells WHITE
            vcolor[i][j] = WHITE;
            //setting all links to cells themselves
            link[i][j] = cell(i,j);
        }
    }

    //Making traversal DFS to keep track of the way each cell is visited.
    
    // setting stack size initially 0
    int NS = 0;
    int NSmax = 10000;
    //Stack itself allocates memory
    cell *S;
    S = new cell[NSmax];
    //adding source to stack S
    S[++NS] = source;
    
    while (NS > 0) {
        //made a current cell to help with the cell direction checking
        cell current = S[--NS];

        //The if statement below checks if the vcolor[i][j] is black or not
        if(vcolor[current.i][current.j] == BLACK){
            continue;
        }

        //setting the cells wall to be black first
        vcolor[current.i][current.j] = BLACK;
        
        //If the current reaches sink then it breaks out
        if(current.i == sink.i && current.j == sink.j){
            break;
        }
        
        //The for loop below goes through all the directions
        for(int k = 0; k < 4; k++){
            //The if statement below checks if adjtable[i][j][k] is true which means if it exist
            if(adjtable[current.i][current.j][k] == true){
                //The if statements below checks for all directions up down left rigth
                if(k==0){
                    if(vcolor[current.i-1][current.j] != BLACK){ 
                        //The cell is pushed on the stack and a link is created
                        S[NS++] = cell(current.i-1, current.j);//up
                        link[current.i-1][current.j] = cell(current.i,current.j);
                    }
                }
                if(k==1){
                    if(vcolor[current.i+1][current.j] != BLACK){
                        //The cell is pushed on the stack and a link is created
                        S[NS++] = cell(current.i+1, current.j);//down
                        link[current.i+1][current.j] = cell(current.i,current.j);
                    }
                }
                if(k==2){
                    if(vcolor[current.i][current.j-1] != BLACK){
                        //The cell is pushed on the stack and a link is created
                        S[NS++] = cell(current.i, current.j-1);//left
                        link[current.i][current.j-1] = cell(current.i,current.j);
                    }
                }
                if(k==3){
                    if(vcolor[current.i][current.j+1] != BLACK){
                        //The cell is pushed on the stack and a link is created
                        S[NS++] = cell(current.i, current.j+1);//right
                        link[current.i][current.j+1] = cell(current.i,current.j);
                    }
                }
                //The if statement below helps create more memory for bigger mazes
                if(NS==NSmax){
                    NSmax*=2;
                    cell *D = new cell[NSmax];
                    memcpy(&D, &S, sizeof(cell) * NS);
                    delete[] S;
                    S = D;
                }
            }
            
        }
    }

    //opening the path file to print the solution path found in the calculation above
    fp = fopen(Poutfile, "w");
    //Printing the header
    fprintf(fp, "PATH %i %i\n", Nrows, Ncols);
    fprintf(fp, "SOURCE %i %i\n", 0, 0);
    fprintf(fp, "SINK %i %i\n", Nrows-1, Ncols -1);
    
    //Setting sink to be the first and only thing in the stack
    cell current = sink;
    S[0] = sink;
    NS = 1;

    //The while loop below links every cell of current cell
    while(current.i != source.i || current.j != source.j){
        current = link[current.i][current.j];
        //current cell is pushed to the stack
        S[NS++] =  current;
    }
   
    //The while loop below goes through the NS and printing the solution to path.txt
    while(NS>=0){
        NS--;
        if(NS>=0){
            fprintf(fp, "%3d %3d\n", S[NS].i, S[NS].j);
        }
    }

    //Closing the path file as the soultion is found and printed
    fclose(fp);
    
    //deallocating memory for 2D vcolor and link arrays
    for(int i = 0; i < Nrows; i++){
        delete[] vcolor[i];
        delete[] link[i];
    }
    delete[] vcolor;
    delete[] link;

    //deallocating memory for stack and 3D adjtable
    for(int i = 0; i < Nrows; i++){
        for(int j = 0; j < Ncols; j++){
            delete[] adjtable[i][j];
        }
        delete[] adjtable[i];
    }
    delete[] adjtable;
}
