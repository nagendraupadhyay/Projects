#ifndef __RNUMGEN_H__
#define __RNUMGEN_H__

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>

using namespace std;
/*class rnumgen {
  public:
    rnumgen(int seed = 0, vector<int> &v) { srand(seed); }

    int rand() const;

  private:
    vector<float> F;
};*/

#endif
