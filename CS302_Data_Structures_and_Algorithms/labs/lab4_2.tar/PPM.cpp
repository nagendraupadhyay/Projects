//Nagendra Upadhyay. This lab is about inputting a ppm format img file 
//and shifting bits and manipulating the RGB pixels.

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <sstream>
using namespace std;

#include "PPM.h"

void PPM::read(string input_file) { 
    //openign the input file
    ifstream fin;
    fin.open(input_file.c_str());
    
    //error checks for file opening, ID, max_value, checking file bytes
    if(!fin.is_open()){
        cerr << "Error: The file did not open." << endl;
        exit(1);
    }

    //reading in the details about the img file
    fin >> ID >> num_rows >> num_cols >> max_value;
    
    if(ID!="P6"){
        cerr << "Error: This is not a P6 format file." << endl;
        exit(1);
    }
    if(max_value!=255){
        cerr << "Error: Max value is over 255." << endl;
        exit(1);
    }
    
    //declaring new img inputs and storing the pixels in img
    char temp[10];
    img = new RGB[num_rows * num_cols];
    
    fin.ignore();
    
    fin.read((char*)img, num_rows * num_cols * 3);
    
    if(fin.gcount()!= num_rows*num_cols*3){
        cerr << "Error: File size not correct. Too few bytes." << endl;
        exit(1);
    }
    //reading the second time to check if there are any extra bytes
    fin.read(temp,1);
    
    if(fin.gcount() != 0){ 
        cerr << "Error: File size not correct. Too many bytes." << endl;
        exit(1);
    }    
    
    fin.close();
}


void PPM::write(string input_file) {
    //making ofstream to print things out
    ofstream fout;
    string add = "_wmsg";
    
    //accessing input file and changing its name
    int size = input_file.length();
    input_file.insert(size-4, add);

    fout.open(input_file);
    
    if(!fout.is_open()){
        cerr << "Error: The file did not open." << endl;
        exit(1);
    }
    
    //printing out and accessing the details about img file
    fout << ID << endl; 
    fout << num_rows << " " << num_cols << endl;
    fout << max_value << endl;
    

    fout.write((char*)img, num_rows * num_cols * 3);
}
