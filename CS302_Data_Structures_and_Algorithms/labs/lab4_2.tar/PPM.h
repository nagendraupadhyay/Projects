#ifndef __PPM_H__
#define __PPM_H__

//Nagendra Upadhyay. This lab is about inputting a ppm format img file 
//and shifting bits and manipulating the RGB pixels.

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>

struct RGB { 
    //making contructors and declaring variables
    RGB() {
        R = 0;
        G = 0;
        B = 0;
    }

    unsigned char R, G, B;
};

class PPM { 
    public:
        //setting contructors for the PPM object
        PPM() {
            num_rows = 0;
            num_cols = 0;
            max_value = 255;
            ID = "P6";
            img = nullptr;
        }
        ~PPM() {
            if(img){
                delete[] img;
            }
        }
        
        //function declaration for functions in PPM.cpp
	    void read(string);
	    void write(string);

	    RGB &operator[](int i) {return img[i];}

	    int get_Npixel() {return num_rows * num_cols;}

    private:
        //variables to stored the details about the img
	    string ID;
        int num_rows;
        int num_cols;
        int max_value;

	    RGB *img;
};


#endif
