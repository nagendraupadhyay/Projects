
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>

#include "Rnumgen.h"
using namespace std;

/*
rnumgen::rnumgen(int seed,vector<int> &v) {
    F.resize(v.size());
    partial_sum(v.begin(), v.end(), F.begin());
    transform(F.begin(), F.end(), F.begin());
    bind2nd(divides<float>(), F.back());
}

int rnumgen::rand() const {
    const double randmax = RAND_MAX + 1.0;
    const double p = (double)rand()/randmax;

    return upper_bound(F.begin(), F.end(), p) - F.begin();
}*/
