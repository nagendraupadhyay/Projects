//Nagendra Upadhyay. This lab is about inputting a ppm format img file 
//and shifting bits and manipulating the RGB pixels.

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <bitset>
using namespace std;

#include "PPM.h"//was PPM.h

#include "Rnumgen.h"
#include "PPM.cpp"


const char EOT = 0x4;	// ASCII: end-of-transmission

void set_pixel_list(vector<int> &pixel_list, int M, PPM &p) {
    //declaring fibonacci array and the magic number
    int i = M;
    int fib [6] = {1, 1, 2, 3, 5, 8};

    //the for loop below is going through the img  and adding the bits in the pixel_list vector
    for(i=M;i < p.get_Npixel(); i=i+fib[(pixel_list.size()-1) %6]){
        pixel_list.push_back(i);
    }
}

/*
void perturb_pixel_list(...) {
  write this
}
*/

void encode(PPM &e, vector<int> &pixel_list){
    string c;
    char d;
    int index = 0;
    getline(cin, c);
    int leg = c.length();
    char shift;
    
    //the for loops below goes through all of the string input and encodes it
    for(int j = 0;j < leg; j++){
        d = c.at(j);
        for(int i = 6; i > -1; i--, index++)
        {
            char shiftBits = (d>>i) &1;
            if(index%3 == 0){
                //going through all the Rs of the img and shifting them too
                e[pixel_list[index]].R = (e[pixel_list[index]].R & 0xFE);
                e[pixel_list[index]].R = e[pixel_list[index]].R | shiftBits;
            }else if(index%3 == 1){
                //going through all the Gs of the img and shifting them too
                e[pixel_list[index]].G = (e[pixel_list[index]].G & 0xFE);
                e[pixel_list[index]].G = e[pixel_list[index]].G | shiftBits;
            }else{
                //going through all the Bs of the img and shifting them too
                e[pixel_list[index]].B = (e[pixel_list[index]].B & 0xFE);
                e[pixel_list[index]].B = e[pixel_list[index]].B | shiftBits;
            }
        }
    }
    
    //The for loop below is for checking EOT
    for(int i=6; i > -1; i--){
        char n = EOT >> i;
        n = n &1;
        if(index%3 == 0){
            e[pixel_list[index]].R = (e[pixel_list[index]].R & 0xFE);
            e[pixel_list[index]].R = e[pixel_list[index]].R | n;
        }else if(index%3 == 1){
            e[pixel_list[index]].G = (e[pixel_list[index]].G & 0xFE);
            e[pixel_list[index]].G = e[pixel_list[index]].G | n;
        }else{
            e[pixel_list[index]].B = (e[pixel_list[index]].B & 0xFE);
            e[pixel_list[index]].B = e[pixel_list[index]].B | n;
        }
        index++;
    }
}


void decode(PPM &e, vector<int> &pixel_list) {
    char d = 0x0;
    int index = 0;
    char shift;
    while(1){
        //going through the input and decoding it
        for(int i = 6; i > -1; i--){
            //checking Rs,Gs, and Bs and also shifting the bits
            if(index%3 == 0){
                shift = e[pixel_list[index]].R;
                shift = (shift & 0x1);
                d = d << 1;
                d = shift | d;
            }else if(index%3 == 1){
                shift = e[pixel_list[index]].G;
                shift = (shift & 0x1);
                d = d << 1;
                d = shift | d;
            }else if(index%3 == 2){
                shift = e[pixel_list[index]].B;
                shift = (shift & 0x1);
                d = d << 1;
                d = shift | d;
            }
            index++;
        }
        //checking if EOT is met and if not then print the chars
        if(d != EOT){
            cout << d;
        }
 
        if(d == EOT){
            break;
        }
        d = 0x0;
    }
    cout << endl;
}

int main(int argc, char *argv[]) {
    //command line args and declaration of objects and variables
    PPM inputData;
    string mode;
    string input_file;
    string M;
    int magicNum;
    
    //checking if a magic number is entered while running the input file
    if(argc==4){
        input_file = argv[3];
        M = argv[2];
        sscanf(M.c_str(), "-m=%d", &magicNum);
    }

    //checking normal file encode/decode input
    if(argc==3){
        input_file = argv[2];
        magicNum = 0;
    }
    
    //setting the encode or decode option to the mode string
    if(strcmp(argv[1], "-encode") == 0){
        mode = "-encode";
    }else if(strcmp(argv[1], "-decode") == 0){
        mode = "-decode";
    }else{
        cerr << "usage: ./Cyptro# -encode|decode imgfile.ppm" << endl;
        exit(1);
    }
    
    //reading in the data from the input file
    inputData.read(input_file);

    vector<int> pixel_list;
    
    //calling set pixel list function to input the bits in a vector
    set_pixel_list(pixel_list, magicNum, inputData);

    //running the desired option 
    if(mode == "-encode"){
        encode(inputData, pixel_list);
        inputData.write(input_file);
    }
    if(mode == "-decode"){
        decode(inputData, pixel_list);
    }
}
