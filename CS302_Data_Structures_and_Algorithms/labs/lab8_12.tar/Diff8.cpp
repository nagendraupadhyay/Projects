//Nagendra Upadhyay. The code below is about comparing two text and finding out the differences using lcs and 
//dynamic programming alignment.
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <climits>
using namespace std;

//The 2d maatrix class helps create  a table to help store lcs values
class matrix {
    public:
        void set_variable(int i, int j){
            table.resize(i);
            for(int a = 0; a < (int)table.size(); a++){
                table[a].resize(j);
            }
        }
        vector<int>& operator[](int j) {
            return table[j];
        }
    private:
        vector<vector<int>> table;
};

//The class below is for text alignment using data from lcs.
class text_align {
    public:
        text_align(){DIAG = 1; VERT = 2; HORZ = 4;};
	    void load_data1(string &);
	    void load_data2(string &);
	    void compute_lcs();
	    void print_diff();

    private:
	    void print_diff(int x,int y);
        void print_edit(int, int, int, int);
        vector<char> trace;
        vector<string> text1;
        vector<string> text2;
        int DIAG;
        int VERT;
        int HORZ;
        int m = 0, n = 0;
        matrix link;
        matrix cost;
};

void text_align::print_edit(int deleteT, int insertT, int count1, int count2){
    //the if statement below is for deleted lines
    if(insertT == 0 && deleteT > 0){
        //d
        //checking if delete is greater than 1 and printing the lines accordingly
        if(deleteT > 1){
            cout << count1 - deleteT + 1 << "," << count1 << "d" <<  count2 <<endl;
            for(int i = count1 - deleteT; i <= count1 - 1; i++){
                cout << "< " << text1[i] << endl;
            }
        }
        //checking if delete is equal to 1 and printing the lines accordingly
        if(deleteT == 1){
            cout << count1 - 1 << "d" << count2 - 1 << endl;
            cout << "< " << text1[count1-deleteT] << endl;
        }
    }
    //the if statement below is for inserted lines
    if(deleteT == 0 && insertT > 0){
        //a
        //checking if insert is greater than 1 and printing the lines accordingly
        if(insertT > 1){
            cout << count1 << "a" << count2 - insertT + 1<< "," << count2 <<endl;
            for(int i = count2 - insertT; i <= count2 - 1; i++){
                cout << "> " << text2[i] << endl;
            }
        }
        //checking if insert is equal to 1 and printing the lines accordingly
        if(insertT == 1){
            cout << count2 - 1 << "a" << count2 - 1 << endl;
            cout << "> " << text2[count2-insertT] << endl;
        }
    }
    //the if statement below is for both delete and insert
    if(deleteT > 0 && insertT > 0){
        //c
        //checking if insert and delete are greater than 1 and printing accordingly
        if(insertT > 1 && deleteT > 1){
            cout << count1 - deleteT + 1 << "," << count1 << "c" <<  count2-insertT+1 << "," << count2 <<endl;
            for(int i = count1 - deleteT; i <= count1 - 1; i++){
                cout << "< " << text1[i] << endl;
            }
            cout << "---" << endl;
            for(int i = count2 - insertT; i <= count2 - 1; i++){
                cout << "> " << text2[i] << endl;
            }
        }
        //checking if insert and delete are equal to 1 and printing accordingly
        if(insertT == 1 && deleteT == 1){
             
            cout << count1 << "c" << count2 << endl;
             cout << "< " << text1[count1-deleteT] << endl;
             cout << "---" << endl;
             cout << "> " << text2[count2-insertT] << endl;
        }
        //checking if insert is greater than 1 and delete is equal to 1 and printing accordingly
        if(insertT > 1 && deleteT == 1){
            cout << count1 - deleteT + 1 << "," << count1 << "c" <<  count2-insertT+1 << "," << count2 <<endl;
            for(int i = count1 - deleteT; i <= count1 - 1; i++){
                cout << "< " << text1[i] << endl;
            }
            cout << "---" << endl;
            for(int i = count2 - insertT; i <= count2 - 1; i++){
                cout << "> " << text2[i] << endl;
            }
        }
        //checking if delete is greater than 1 and insert is equal to 1 and printing accordingly
        if(insertT == 1 && deleteT > 1){
            cout << count1 - deleteT + 1 << "," << count1 << "c" <<  count2-insertT+1 << "," << count2 <<endl;
            for(int i = count1 - deleteT; i <= count1 - 1; i++){
                cout << "< " << text2[i] << endl;
            }
            cout << "---" << endl;
            for(int i = count2 - insertT; i <= count2 - 1; i++){
                cout << "> " << text2[i] << endl;
            }
        }
    }
}

void text_align::print_diff(int x, int y){
    //declaring variables to use for printing
    int deleteT = 0;
    int insertT = 0;
    int count1 = 0;
    int count2 = 0;
    
    //Entering the base case below
    if(x==0 && y==0) {
        for(int k = (int)trace.size() - 1; 0 <= k; k--) {
            //the if statement below checks for trace being DIAG direction
            if(trace[k] == DIAG){
                //The print is called with all the needed parameters
                print_edit(deleteT, insertT, count1, count2);
                count1++;
                count2++;
                deleteT = 0;
                insertT = 0;
            }
            if(trace[k] == VERT){
                //the if statement checks for trace being VERT direction
                deleteT++;
                count1++;
            }
            if(trace[k] == HORZ){
                //the if statement checks for trace being HORZ direction
                insertT++;
                count2++;
            }
        }
        //the print call below is for general printing
        print_edit(deleteT, insertT, count1, count2);
        return;
    }
    //The if statements below checks for link and directions
    if(link[x][y] & DIAG) {
        //the statements also recursively call the print_diff function
        trace.push_back(DIAG);
        print_diff(x-1, y-1);
    }else if(link[x][y] & VERT) {
        //the statements also recursively call the print_diff function
        trace.push_back(VERT);
        print_diff(x-1, y);
    }else if(link[x][y] & HORZ) {
        //the statements also recursively call the print_diff function
        trace.push_back(HORZ);
        print_diff(x, y-1);
    }
}

//The function below takes in the inputfile and stores the data line by line
void text_align::load_data1(string &inputfile1){
    ifstream input;
    input.open(inputfile1);
    //making a temp to store the data.
    string buff1;
    
    while(getline(input, buff1)){
        m++;
        //storing the data in buff
        text1.push_back(buff1);
        if(input.eof()){
            break;
        }
    }
    input.close();
}

//The function below takes in the inputfile and stores the data line by line
void text_align::load_data2(string &inputfile2){
    ifstream input;
    input.open(inputfile2);
    //making a temp to store the data.
    string buff2;
    
    while(getline(input, buff2)){
        n++;
        //storing the data in buff
        text2.push_back(buff2);
        if(input.eof()){
            break;
        }
    }
    input.close();
}

//The code below computes the lcs of each and every line and stores it in the 2d table
void text_align::compute_lcs(){
    cost.set_variable(m+1, n+1);
    link.set_variable(m+1, n+1);
    cost[0][0] = 0;
    link[0][0] = 0;

    //the for loops goes through all the lines or chars and checks for connections of HORZ and VERT
    for (int i = 1; i <= m; i++) {
        cost[i][0] = cost[i-1][0] + 1;
        link[i][0] = VERT;
    }
    for (int j=1; j <= n; j++) {
        cost[0][j] = cost[0][j-1] + 1;
        link[0][j] = HORZ;
    }
    //The for loop below goes through the table and checks if the links and cost are set properly with correct directions
    for (int i=1; i <= m; i++) {
        for (int j=1; j<=n; j++) {
            cost[i][j] = INT_MAX;
            if(text1[i-1] == text2[j-1]){
                cost[i][j] = cost[i-1][j-1];
                link[i][j] = DIAG;
            }
            int delcost = cost[i-1][j] + 1;
            if (delcost < cost[i][j]) {
                cost[i][j] = delcost;
                link[i][j] = VERT;
            }
            int inscost = cost[i][j-1] + 1;
            if (inscost < cost[i][j]) {
                cost[i][j] = inscost;
                link[i][j] = HORZ;
            }
        }
    }
}

//The function below is a wrapper for the print_diff(int, int) function
void text_align::print_diff(){
    print_diff(m,n);
}

int main(int argc, char *argv[]) {
    // command line checks
    ifstream fin;
    string inputfile1;
    string inputfile2;

    if(argc == 3){
        inputfile1 = argv[1];
        inputfile2 = argv[2];
    }else{
        cerr << "Error: ./Diff8 file1.txt file2.txt" << endl;
    }
    
    text_align align;

    fin.open(inputfile1);
    // reading the text from file1 into text_align::text1 buffer
    align.load_data1(inputfile1);

    fin.open(inputfile2);
    // read the text from file2 into text_align::text2 buffer
    align.load_data2(inputfile2);
    
    //calling the lcs and print_diff functions
    align.compute_lcs();
    align.print_diff();
}
