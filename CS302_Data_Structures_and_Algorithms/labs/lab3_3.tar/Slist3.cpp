// include header file(s) needed

//Sep 22, 2022. Nagendra Upadhyay
//Lab 3 is about making a sort function that sorts data using std::sort and std::sable_sort(with the help of smart pointer) from a single linked list.

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>

using namespace std;

#include "Slist.h"

class data {
public:
    //using static variable to count the ID.
    static int count;

    //Made a boolean operator< to campare with the pivot.
    bool operator< (const data& B ){
        if(lastname == B.lastname){
            if(firstname==B.firstname)
                return phonenum<B.phonenum;
            else
                return firstname<B.firstname;
        }
        else 
           return lastname < B.lastname;
    }

    friend istream & operator>>(istream &, data &);
    friend ostream & operator<<(ostream &, const data &);

  private:
    string firstname;
    string lastname;
    string phonenum;
    //declaring node number output ID variable
    int ID;
};



istream & operator>> (istream &in, data &r) {
    //extracting firstname, lastname, and phonenum from the input files.
    in >> r.firstname;
    in >> r.lastname;
    in >> r.phonenum;
    
    //updaing the ID everytime a new input from the list is taken in.
    r.ID = r.count++;
    return in;
}

ostream & operator<< (ostream &out, const data &r) {
    out << " " << left << r.lastname <<  " " << setw(24 - r.lastname.length()) << r.firstname << r.phonenum << setw(9) << right << r.ID;
    return out;
}

template <typename Tdata>
void printlist(Tdata p0, Tdata p1) { 
    //printing the list out.
    for(;p0 != p1; ++p0)
    {
        cout << (*p0) << endl;
    }
}


int data::count = 1;

int main(int argc, char *argv[]) {
    //Command line arguments
    ifstream fin;
    //Strings to store the input_file name and kind of sorting.
    string input_file;
    string sorting;
    

    //setting if statements to make sure to correctly open the input file because of different argv values.
    if(argc==3)
    {
       input_file = argv[2];
    }else{
        cerr << "usage: ./slist3Sol -mergesort|quicksort|qsort_r3 file.txt" << endl;
    }

    fin.open(input_file);

    //Checking the strings and setting them equal to the specific sort name.
    if(strcmp(argv[1], "-mergesort") == 0){
        sorting = "-mergesort";
    }else if(strcmp(argv[1], "-quicksort") == 0){
        sorting = "-quicksort";
    }else if(strcmp(argv[1], "-qsort_r3") == 0){
        sorting = "-qsort_r3";
    }else{
        cerr << "usage: ./slist3Sol -mergesort|quicksort|qsort_r3 file.txt" << endl;
    }

    slist<data> A;

    data din;
    while (fin >> din){
        A.push_back(din);
    }
    fin.close();
    
    //calling sort() for the desired sorting method
    if(sorting == "-mergesort")
        A.sort("-mergesort");
    if(sorting == "-quicksort")
        A.sort("-quicksort");

    //printing the list after getting sorted.
    printlist(A.begin(), A.end());
}
