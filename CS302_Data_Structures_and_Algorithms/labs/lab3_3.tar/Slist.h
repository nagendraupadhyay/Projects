#ifndef SLIST_H
#define SLIST_H

//Sep 22, 2022. Nagendra Upadhyay. 
//Lab 3 is about making a sort function that sorts data using std::sort and std::sable_sort(with the help of smart pointer) from a single linked list.

#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>

template <class T>
class slist {
  private:
    
    struct node {
        node() { data = T(); next = NULL; }
        //making node constructor below.
        node (const T &n){data = n; next=NULL;}  
        
        //implementing an overloader < operator
        bool operator< (node& r){
            return data < r.data;
        }

        T data;
        node *next;
    };
    
    //implementing the smart pointer.
    class sptr{
        public:
            sptr(node *_ptr = NULL){ptr = _ptr;}
            bool operator< (const sptr &rhs) const{
                return *ptr < *rhs.ptr;
            }
            operator node * () const {return ptr;}
        private:
            node *ptr;
    };


  public:
    class iterator {
      public:
        iterator() { p = NULL; }
        T & operator*() { return p->data; }
        iterator & operator++() { p = p->next; return *this; }
        bool operator!=(const iterator & rhs) const { return p != rhs.p; }

      private:
        iterator(node *n_p) { p = n_p; }
        node *p;

      friend class slist<T>;
    };

  public:
    slist();
    ~slist();

    void push_back(const T &);
    void sort(const string &);

    iterator begin() { return iterator(head->next); }
    iterator end() { return iterator(NULL); }

  private:
    node *head;
    node *tail;
};

template <typename T>
slist<T>::slist() {
  head = new node();
  tail = head;
}

template <typename T>
slist<T>::~slist() {
  while (head->next != NULL) {
    node *p = head->next;
    head->next = p->next;
    delete p;
  }
  delete head;

  head = NULL;
  tail = NULL;
}

template <typename T>
void slist<T>::push_back(const T &din) {
  tail->next = new node(din);
  tail = tail->next;
}

template <typename T>
void slist<T>::sort(const string &algname) {
    //setting up smart pointer array called Ap
    std::vector<sptr> Ap;
    int listSize = 0;
    node* current = head;
    while(current != NULL)
    {
        //determining number of list elements
        listSize++;
        current = current->next;
        Ap.push_back(sptr(current));
    }
    Ap.pop_back();

    if(algname == "-quicksort"){
        std::sort(Ap.begin(), Ap.end());
    }

    if(algname == "-mergesort"){
        std::stable_sort(Ap.begin(), Ap.end());
    }

    //using sorted Ap vector to relink list
    current = head;
    for(int i = 0; i < (int)Ap.size(); i++)
    {
        current->next = Ap[i];
        current = current->next;
    }
    current->next = NULL;
    tail = current;
}
#endif // SLIST_H
