//Nagendra Upadhyay. Lab5. The code below is about graphs manipulation. 
//In this code a person is given random friends and those random friends have their own random friends. 
//A is friends with B and B is friends with C, the code below makes A and C friends too.
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>
using namespace std;

class vtable {
  public:
    int size() { 
        //setting a return size of 1D-array
        return vertexLabels.size();
    }
    void push(string & names) { 
        //adding names to the vertex label
        vertexLabels.push_back(names);
    }
    string operator[](int i) { 
        //returning i of the vertex label 
        return vertexLabels[i];
    }
    vector<string>::iterator begin() { 
        //setting return begin iterator 
        return vertexLabels.begin();
    }
    vector<string>::iterator end() { 
        //setting return end iterator 
        return vertexLabels.end();
    }

  private:
    //1D-array vertex labels;
    vector<string> vertexLabels;
};

class adjtable {
  public:
    int size() { 
        //returning the size of 2D-array
        return edges.size();
    }
    void set_size(int n) { 
        //setting size of 2D-array 
        edges.assign(n, vector<int>(n));
    }
    vector<int>& operator[](int j) {
        //returning j of the edges
        return edges[j];
    }

  private:
    //2D-array edges;
    vector<vector<int>> edges;
};

void set_oldfriends(vtable &names, adjtable &friends, int M0, int M1) {
    //declaring all the necessary variables
    int N = (int)names.size();
    friends.set_size(N);
    vector<int> do_know(N);
    int Mnum;
    int randNum;

    //setting the do_know vector with 0,1,2,3,etc to the size of N.
    for(int a = 0; a < N; a++){
        do_know[a] = a;
    }
    
    //The for loop below goes through all the indices of names
    for(int i = 0; i < N; i++){
        //a random number of friends are generated with the user given M values.
        Mnum = M0 + rand() % (M1 - M0 + 1);
        //the loop below goes through those friends
        for(int z = 0; z < Mnum; z++) {
            //one more random number is generated to check if the person is a friend or not
            randNum = z + rand() % (N-z);
            //the while loop below checks if the person is a friend and if they are than new number is generated
            while(do_know[randNum] == i){
                randNum = z + rand() % (N-z);
            }
            //when a friend is found it is swaped and added
            swap(do_know[z], do_know[randNum]);
            friends[i][do_know[z]] = 1;
            friends[do_know[z]][i] = 1;
        }
    }
}

void set_newfriends(adjtable &friends, adjtable &new_friends) {
    //declaring all the necessary variables
    int N = (int)friends.size();
    new_friends.set_size(N);

    for(int i = 0; i < N; i++) {
        //The for loop below goes through the friends
        for(int m = 0; m < (int)friends[i].size(); m++){
            //the if statement below checks if the people are friends
            if(friends[i][m] == 1){
                for(int o = 0; o < (int)friends[m].size(); o++) {
                    //the if statement below checks if o is already added to the friend list or not
                    if(o!=i && friends[m][o] == 1){
                        //update corresponding pairs of new_friends entries
                        new_friends[i][o] = 1;
                        new_friends[o][i] = 1;
                    }
                }
            }
        }
    }
}

void writetofile(const char *fname, vtable &names, adjtable &friends) {
    //opening the file below and also declaring the variables
    ofstream fout;
    fout.open(fname);
    int N = (int)names.size();
    int max = 0;
    
    //the for loop below goes through all names and compares its size with max
    for(int j = 0; j < N; j++){
        if((int)names[j].size() > max){
            //if the size of names is greater than max then they are set to max
            max = names[j].size();
        }
    }
    
    //the for loop below is for printing all the names of the person's friends.
    for (int i=0; i<N; i++) {
        //setting a counter to limit the printing of friends to 8
        int friendcounter = 0;
        fout << setw(max) << left << names[i] << " : ";
        //the for loop prints all the friends properly with the help of max which is the size of the names indices
        for (int f = 0; f < (int)friends[f].size(); f++){
            if(friends[i][f]==1){
                fout << setw(max) << left << names[f] << " ";
                friendcounter++;
            }
            if(friendcounter > 7){
                break;
            }
        }
        fout << endl;
    }
    fout.close();
}

int main(int argc, char *argv[]) {
    ifstream fin;
    int seed = 0; // default seed value
    int M0 = 1;   // min number of friends
    int M1 = 2;   // max number of friends
    string name;

    //command line parsing and storing all the file input
    for(int i = 1; i < argc; i++) {
        if(strncmp(argv[i], "-M0=", 4) == 0){
            sscanf(&argv[i][4], "%d", &M0);
        }
        else if(strncmp(argv[i], "-M1=", 4) == 0){
            sscanf(&argv[i][4], "%d", &M1);
        }
        else if(strncmp(argv[i], "-seed=", 6) == 0){
            sscanf(&argv[i][6], "%d", &seed);
        }
        else{
            cerr << "usage:incorrect call.";
            break;
        }
    }

    //seed random number generator and names indices
    srand(seed);
    vtable names;
    
    fin.open("names.txt");
    
    //populating vtable with names read from stdin
    if(fin.is_open()){
        while(fin >> name)
            names.push(name);
    }
    
    //sorting the names
    sort(names.begin(), names.end());
    
    //setting the most important variables
    adjtable friends;
    adjtable new_friends;

    //making the function calls with files for output
    set_oldfriends(names, friends, M0, M1); 
    writetofile("doknow1.txt", names, friends);

    set_newfriends(friends, new_friends);
    writetofile("mightknow1.txt", names, new_friends);
}
