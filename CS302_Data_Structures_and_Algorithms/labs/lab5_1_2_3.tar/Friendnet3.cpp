//Nagendra Upadhyay. Lab5. The code below is about graphs manipulation.
//In this code a person is given random friends and those random friends have their own random friends.
//A is friends with B and B is friends with C, the code below makes A and C friends too.
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <fstream>
#include <algorithm>
#include <set>
using namespace std;

class vtable {
  public:
    int size() {
        //setting a return size of 1D-array
        return vertexLabels.size();
    }
    void push(string & names) { 
        //adding names to the vertex label
        vertexLabels.push_back(names);
    }
    string operator[](int i) {
        //returning i of the vertex label
        return vertexLabels[i];
    }
    vector<string>::iterator begin() {
        //setting return begin iterator 
        return vertexLabels.begin();
    }
    vector<string>::iterator end() {
        //setting return end iterator  
        return vertexLabels.end();
    }

  private:
    //1D-array vertex labels;
    vector<string> vertexLabels;
};

class adjtable {
  public:
    int size() {
        //returning the size of 2D-array
        return edges.size();
    }
    void set_size(int n) { 
        //clearing the 2D array and resizing it
        edges.clear();
        edges.resize(n);
    }
    set<int>& operator[](int j) {
        //returning j of the edges as a set operator
        return edges[j];
    }

  private:
    //2D-array edges;
    vector<set<int>> edges;
};

void set_oldfriends(vtable &names, adjtable &friends, int M0, int M1) {
    //declaring all the necessary variables
    int N = (int)names.size();
    friends.set_size(N);
    vector<int> do_know(N);
    int Mnum;
    int randNum;

    //setting the do_know vector with 0,1,2,3,etc to the size of N.
    for(int a = 0; a < N; a++){
        do_know[a] = a;
    }

    //The for loop below goes through all the indices of names
    for(int i = 0; i < N; i++){
        //a random number of friends are generated with the user given M values.
        Mnum = M0 + rand() % (M1 - M0 + 1);
        //the loop below goes through those friends
        for(int z = 0; z < Mnum; z++) {
            //one more random number is generated to check if the person is a friend or not
            randNum = z + rand() % (N-z);
            //the while loop below checks if the person is a friend and if they are than new number is generated
            while(do_know[randNum] == i){
                randNum = z + rand() % (N-z);
            }
            //when a friend is found it is swaped and inserted to friends
            swap(do_know[z], do_know[randNum]);
            friends[i].insert(do_know[z]);
            friends[do_know[z]].insert(i);
        }
    }
}

void set_newfriends(adjtable &friends, adjtable &new_friends) {
    //declaring all the necessary variables
    int N = (int)friends.size();
    new_friends.set_size(N);
    set<int>::iterator p0;
    set<int>::iterator p1;


    for(int i=0; i<N; i++) {
        //The for loops below goes through the friends using set iterators
        for(p0 = friends[i].begin(); p0 != friends[i].end(); p0++){
            for(p1 = friends[*p0].begin(); p1 != friends[*p0].end(); p1++) {
                //the if statement checks if the person being check is already a friend or not
                if(i != *p1){
                    //update corresponding pairs of new_friends entries using insert
                    new_friends[i].insert(*p1);
                    new_friends[*p1].insert(i);
                }
            }
        }
    }
    //there is no need of using unique() to remove the duplicates as set functions automatically get rid of them
}


void writetofile(const char *fname, vtable &names, adjtable &friends) {
    //opening the file below and also declaring the variables
    ofstream fout;
    fout.open(fname);
    int N = (int)names.size();
    int max = 0;
     
    //the for loop below goes through all names and compares its size with max
    for(int j = 0; j < N; j++){
        if((int)names[j].size() > max){
            //if the size of names is greater than max then they are set to max
            max = names[j].size();
        }
    }

    //the for loop below is for printing all the names of the person's friends.
    for (int i=0; i<N; i++) {
        //setting a counter to limit the printing of friends to 8
        int friendcounter = 0;
        fout << setw(max) << left << names[i] << " : ";
        set<int>::iterator p0;// = friends[i].begin();
        
        //the for loop prints all the friends properly with the help of max which is the size of the names indices using set iterators
        for (p0 = friends[i].begin(); p0 != friends[i].end(); p0++){
            fout << setw(max) << left << names[*p0] << " ";
            friendcounter++;
            
            if(friendcounter > 7){
                break;
            }
        }
        fout << endl;
    }
    fout.close();
}

int main(int argc, char *argv[]) {
    ifstream fin;
    int seed = 0; // default seed value
    int M0 = 1;   // min number of friends
    int M1 = 2;   // max number of friends
    string name;

    //command line parsing and storing all the file input
    for(int i = 1; i < argc; i++) {
        if(strncmp(argv[i], "-M0=", 4) == 0){
            sscanf(&argv[i][4], "%d", &M0);
        }
        else if(strncmp(argv[i], "-M1=", 4) == 0){
            sscanf(&argv[i][4], "%d", &M1);
        }
        else if(strncmp(argv[i], "-seed=", 6) == 0){
            sscanf(&argv[i][6], "%d", &seed);
        }
        else{
            cerr << "usage:incorrect file call";
            break;
        }
    }
    //seed random number generator
    srand(seed);
    vtable names; 

    fin.open("names.txt");

    //populating vtable with names read from stdin
    if(fin.is_open()){
        while(fin >> name)
            names.push(name);
    }

    //sorting the names
    sort(names.begin(), names.end());
    
    //setting the most important variables
    adjtable friends;
    adjtable new_friends;

    //making the function calls with files for output
    set_oldfriends(names, friends, M0, M1); 
    writetofile("doknow3.txt", names, friends);

    set_newfriends(friends, new_friends);
    writetofile("mightknow3.txt", names, new_friends);
}
