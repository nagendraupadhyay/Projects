#Secure Remote Password(Python)
##How to run the code?
To run the code, use the complier in vscode:
- Just normally run and compile the python file in VScode

##Some useful things
- The code has 3 different codes in it. The step 1 code does steps 1 and 2. The step 2 code does step 3. The step 3 code does steps 4 and 5.
- When you run the code, you will have to copy and paste the value of p and g that you have on pass-off server. When that is done step 1 code will run and give you the Public key(g^a) and the random a value that it used.
- Now, block the code for step 1 and unblock the code for step 2 which is provided right underneath step 1's code. Copy paste all the required hardcoded values like (g^a), B, g, p, a, password, salt, username, and number of iterations. Run the code and you will get the values for x, k, (g^b), u, and the shared key which all will be in integer values.
- Now, step 2 is done and block the code for it. And underneath it unblock the code for step 3, copy and paste the required hardcoded values of (g^a), (g^b), g, p, and shared key. Run the code and you shall get the output of M1 and M2 in hex.