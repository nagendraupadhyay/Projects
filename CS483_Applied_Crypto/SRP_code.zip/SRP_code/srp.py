# Nagendra Upadhyay. Cosc483/583. Project: Secure Remote Password.

# Step 1
import hashlib
import random

# Arbitrary precision integer library functions
def int_to_bytes(n):
    return n.to_bytes((n.bit_length() + 7) // 8, 'big')

def bytes_to_int(b):
    return int.from_bytes(b, 'big')

def hex_to_bytes(hex_string):
    return bytes.fromhex(hex_string)

def bytes_to_hex(byte_array):
    return byte_array.hex()

g = 5
p = 233000556327543348946447470779219175150430130236907257523476085501968599658761371268535640963004707302492862642690597042148035540759198167263992070601617519279204228564031769469422146187139698860509698350226540759311033166697559129871348428777658832731699421786638279199926610332604408923157248859637890960407

# Generate a random private key 'a'
a = random.randint(1, p-1)

# Calculate the public key (g^a) mod p
public_key = pow(g, a, p)

# Convert the public key to bytes in big-endian format
public_key_bytes = int_to_bytes(public_key)

# Print the public key and its byte representation
print("Public Key:", public_key)
print("Public Key (bytes):", public_key_bytes)
print("a value:", a)


# Step 2
"""
import hashlib
import random

def int_to_bytes(n):
    return n.to_bytes((n.bit_length() + 7) // 8, 'big')

def bytes_to_int(b):
    return int.from_bytes(b, 'big')

def hex_to_bytes(hex_string):
    return bytes.fromhex(hex_string)

def bytes_to_hex(byte_array):
    return byte_array.hex()

# Step a: Calculate hashed password x = H((salt || password)^1000)
password = "calcaneum"
salt_hex = "49cd7751"
iterations = 1000

# Concatenate salt and password, then encode to bytes using ASCII
salt_password_bytes = (bytes.fromhex(salt_hex) + password.encode('ascii'))

# Hash the concatenated value 'salt_password' 1000 times using SHA-256
x = salt_password_bytes
for _ in range(iterations):
    x = hashlib.sha256(x).digest()

B_star = 211804995983893692644235843208018958773352749549241788991709433821387485377537077475185117213211500229180171977622228052806464505527469954415867286171607647609048741483251632169881223548490895589912007581473030448899010663974168619531960995075675817919176291367539425423147946410365098915913613677790587867148
g_a = 62757775132209101094562500017051337416351188693292232662480948627621978313279519643522806854104810609691157702332165479108012337560039147519786040799712436068539428390333065511307279876198479618817860482222194502093228111243500070051699195347160195060438698711656187691646214236003372307387715265376547683993
g = 5
p = 233000556327543348946447470779219175150430130236907257523476085501968599658761371268535640963004707302492862642690597042148035540759198167263992070601617519279204228564031769469422146187139698860509698350226540759311033166697559129871348428777658832731699421786638279199926610332604408923157248859637890960407
a = 99792087996486065035912581273954832360688594322810320104058424676823038294944828166376982555498236522345821280568214305376307743752284612465837662524257200253765937836923834400198142289250081195000862188071000498172204804998997109099260494519694636603075770708905771935290754807464079429457816284745461618006

# Calculate k = H(p || g)
k = hashlib.sha256(int_to_bytes(p) + int_to_bytes(g)).digest()

# Calculate public key (g^b) ≡ B* - k * (g^x) (mod p)
public_key = (B_star - (bytes_to_int(k) * pow(g, bytes_to_int(x), p))) % p

# Step c: Calculate values u = H((g^a) || (g^b))
u = hashlib.sha256(int_to_bytes(g_a) + int_to_bytes(public_key)).digest()

# Step d: Calculate shared key ((g^b)^a+u*x) (mod p)
shared_key = pow(public_key, a + bytes_to_int(u) * bytes_to_int(x), p)

# Print the calculated values
print("Hashed Password (x):", bytes_to_int(x))
print("k:", bytes_to_int(k))
print("Public Key (g^b):", public_key)
print("Value of u:", bytes_to_int(u))
print("Shared Key:", shared_key)
"""


# Step 3
"""
import hashlib

def int_to_bytes(n):
    return n.to_bytes((n.bit_length() + 7) // 8, 'big')

def bytes_to_int(b):
    return int.from_bytes(b, 'big')

def hex_to_bytes(hex_string):
    return bytes.fromhex(hex_string)

def bytes_to_hex(byte_array):
    return byte_array.hex()

def bytes_xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

salt_hex = "49cd7751"
netId = "nupadhy3"
g_a = 62757775132209101094562500017051337416351188693292232662480948627621978313279519643522806854104810609691157702332165479108012337560039147519786040799712436068539428390333065511307279876198479618817860482222194502093228111243500070051699195347160195060438698711656187691646214236003372307387715265376547683993
g = 5
p = 233000556327543348946447470779219175150430130236907257523476085501968599658761371268535640963004707302492862642690597042148035540759198167263992070601617519279204228564031769469422146187139698860509698350226540759311033166697559129871348428777658832731699421786638279199926610332604408923157248859637890960407
g_b = 82613279792300821522332900872523961949884886754825570880262391484544492178393327098184869489724437515522065600488371510855783152586334331650830346465781438818109080879516544428263642708318822918281522136250679495355026045444522370160730236184496379544652834322361262694274488445390652003659142094380662665593
shared_key = 25650893735541708956421949850605253021488209088479023162145885654001569632633321439960777282480174967638223354361910552969955884041643772358368124882759168101609128728585891149867986087145955006039339046047070621039253849413326499881168920451435734886741103865165292784014331565429850179747216901892869082414

# Task 4: Calculate M1
def calculate_M1(p, g, netId, salt, g_a, g_b, shared_key):
    # Convert p, g, netId, salt, g_a, g_b, and shared_key to bytes
    p_bytes = int_to_bytes(p)
    g_bytes = int_to_bytes(g)
    netId_bytes = netId.encode('ascii')
    salt_bytes = hex_to_bytes(salt)
    g_a_bytes = int_to_bytes(g_a)
    g_b_bytes = int_to_bytes(g_b)
    shared_key_bytes = int_to_bytes(shared_key)

    # Calculate H(p) XOR H(g)
    p_hash = hashlib.sha256(p_bytes).digest()
    g_hash = hashlib.sha256(g_bytes).digest()
    xor_result = bytes_xor(p_hash, g_hash)
    # Calculate M1
    m1 = hashlib.sha256(xor_result + hashlib.sha256(netId_bytes).digest() + salt_bytes + g_a_bytes + g_b_bytes + shared_key_bytes).hexdigest()
    return m1

# Task 5: Calculate M2
def calculate_M2(g_a, M1, shared_key):
    # Convert g_a and shared_key to bytes
    g_a_bytes = int_to_bytes(g_a)
    shared_key_bytes = int_to_bytes(shared_key)
    # Calculate M2
    m2 = hashlib.sha256(g_a_bytes + bytes.fromhex(M1) + shared_key_bytes).hexdigest()
    return m2

M1 = calculate_M1(p, g, netId, salt_hex, g_a, g_b, shared_key)
M2 = calculate_M2(g_a, M1, shared_key)

# Print the results in hex
print("M1:", M1)
print("M2:", M2)
"""