#Public-Key(Python)
##How to run the code?
To run the code, use the complier in vscode:
- Just normally run and compile the python file in VScode

##Some useful things
- Code has hard coded inputs value which were generated using the command that are commented in the line right above the input value.
- The code gives you all the input that are needed to run the output from the code onto the pass-off server.