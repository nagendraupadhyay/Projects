# Nagendra Upadhyay. COSC 483. Public-Key Cryptography.
import random
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from Crypto.Hash import SHA256

# PART 1
# Function to perform fast modular exponentiation
# Computes (base^exponent) % modulus efficiently using binary exponentiation
def fast_modular_exponentiation(base, exponent, modulus):
    result = 1
    while exponent > 0:
        if exponent % 2 == 1:
            result = (result * base) % modulus
        base = (base * base) % modulus
        exponent = exponent // 2
    return result

# Function to perform Miller-Rabin primality test
# Determines whether a given number n is probably prime with a specified number of iterations (k)
def miller_rabin_primality_test(n, k=5):
    if n == 2 or n == 3:
        return True # 2 and 3 are prime numbers
    if n % 2 == 0 or n == 1:
        return False # Even numbers (except 2) and 1 are not prime

    r, s = 0, n - 1
    while s % 2 == 0:
        r += 1
        s //= 2 # Calculate r and s such that n-1 = (2^r) * s

    for _ in range(k):
        a = random.randint(2, n - 2) # Pick a random integer between 2 and n-2
        x = fast_modular_exponentiation(a, s, n) # Compute a^s mod n
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = fast_modular_exponentiation(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

# Function to perform extended Euclidean algorithm to calculate GCD and coefficients for Bézout's identity
def extended_euclidean_algorithm(a, b):
    if b == 0:
        return a, 1, 0
    gcd, x, y = extended_euclidean_algorithm(b, a % b)
    return gcd, y, x - (a // b) * y

# PART 2
# Function to generate Diffie-Hellman parameters (prime p and base g)
# Uses Miller-Rabin primality test to ensure p and (p-1)/2 are prime
def generate_diffie_hellman_parameters():
    while True:
        p = random.randint(2**1023, 2**1024 - 1)
        if miller_rabin_primality_test(p) and miller_rabin_primality_test((p - 1) // 2):
            break
    g = 5
    return p, g

# Function to calculate the Diffie-Hellman public key
# Computes (g^private_key) % p using fast modular exponentiation
def calculate_diffie_hellman_public_key(p, g, private_key):
    return fast_modular_exponentiation(g, private_key, p)

# PART 3
# Function to generate an RSA key pair with specified bit length (default: 1024 bits)
# It generates two large prime numbers, calculates the RSA modulus (n), the totient φ(n), and private exponent (d)
def generate_rsa_keypair(bit_length=1024):
    #p = generate_prime(bit_length)
    p = 172160020762813976423989914504457043913278603711989539797196645504457817189463519518266663315441740710842553531570881309519345439057188934219173898877681265611288716781793286320143182586127738584160666520753627730207464561665405566824657027869858657383459123342803372169907697338414272520149399174686595759899
    #q = generate_prime(bit_length)
    q = 137229388193495136138439726702589289317613266998494720721853553497452441423340492732048332116088684424423694275134455977102397879390225884459067394728933650857677197134084597777998387179157224570641792292132470848049049879107308550856864236588459066744679236395360659758747119489349052533206319709314253548987
    
    # Calculate the RSA modulus (n) and the totient φ(n)
    n = p * q
    phi_n = (p - 1) * (q - 1)
    e = 65537

    # Calculate the private exponent (d) using the extended Euclidean algorithm
    _, d, _ = extended_euclidean_algorithm(e, phi_n)
    d = d % phi_n
    print("\nPART 3 RSA")
    print("\nPrime Number (p): ", p)
    print("\nPrime Number (q): ", q)
    print("\nRSA Modulus (n): ", n)
    print("\nφ(n): ", phi_n)
    print("\nRSA private exponent (d):", d)
    return ((e, n), (d, n))

# Function to generate a prime number with the specified bit length using the Miller-Rabin primality test
def generate_prime(bit_length):
    prime_candidate = random.getrandbits(bit_length)
    prime_candidate |= (1 << (bit_length - 1)) | 1
    while not miller_rabin_primality_test(prime_candidate):
        prime_candidate += 2
    return prime_candidate

# Function to perform RSA encryption using the public key (e, n)
def rsa_encrypt(message, public_key):
    e, n = public_key
    return fast_modular_exponentiation(message, e, n)

# Function to perform RSA decryption using the private key (d, n)
def rsa_decrypt(ciphertext, private_key):
    d, n = private_key
    return fast_modular_exponentiation(ciphertext, d, n)


# PART 2 code#######
#p, g = generate_diffie_hellman_parameters()
p = 165879421167263841792267991583418045203197883504991646529228428545314103850160926462686639357812851078236764650868194249031806637000367370993707562504511175420259439426827380096494155664218094392481198732132026729825677536609221095049883503445362676707608642700981566200092963287955485225744117267062230133807
g = 5
print("\nPART 2")
private_key = random.randint(2, p - 2)
public_key = calculate_diffie_hellman_public_key(p, g, private_key)

print("\nPrime modulus (p):", p)
print("\nPublic key (g^a):", public_key)

private_a = 80360649596277826684324052044096973131274980765017471836018097089110641010874
public_A = fast_modular_exponentiation(g, private_a, p)
public_B = 9970598607149851714993988463878008602697393213155516856590406628473651234909818011382772814566411667311923513059102682618010553446477005086353752195316923292900372882007215742855174202892021302118940951798155371426014650632150088315379261162081757901022985774383721511512079589340752225499712308266422492241

shared_key = fast_modular_exponentiation(public_B, private_a, p)

print("\nShared Diffie-Hellman key (g^a·b)", shared_key)

ciphertext_hex = "247c393c60ec66397c835aa1ec723580d1e1cd9df61c2cc8f8e60ae4b2706af737791eea7cedc96861f7a998208ce2cf38c9539c2d08c616c5d81a95f8e01ecc95853474ddb8963579f4d93fc92dd5829bd8f117ffa2ca76bf2294929e5a5bf5d33b3ee395507984b8af0ebe270568438a5e28194d2452354690ff4118a3ec4c724b9ecd7e03bf915c7f72e6003600b646e9d39bbc363f914ea81cb8ffeb4f6427b1fe539e2a6199572225338a6dfacda265c53a6dc342c7a9805b88848dd0bbd85f5ff451dcc4445cbe1ef29e4add9c75a038bd72a738b4e506894c1d03a894265643e3c22e77e61271a222d386881c7721e0c8217685864bfacfd755f09a182795593a01d07feac56f397005d9ab942c0b41323e6808b515b78ac9be3cf14a8819d775e907aabbd33fafe4be0dad3f5ef00bb8445a461e882e67d440c4e964"
ciphertext_bytes = bytes.fromhex(ciphertext_hex)
vi_hex = "67b557009decd0b48548e8bcf4b09cf3"
vi_bytes = bytes.fromhex(vi_hex)

shared_key_bytes = shared_key.to_bytes((shared_key.bit_length() + 7) // 8, 'big')
hash_object = SHA256.new(data=shared_key_bytes)
hashed_key = hash_object.digest()
encryption_key = hashed_key[:16]
cipher = AES.new(encryption_key, AES.MODE_CBC, iv = vi_bytes)
plaintext_bytes = unpad(cipher.decrypt(ciphertext_bytes), AES.block_size)
print("\n")
print("Decrypted Message: ", plaintext_bytes)
############

# PART 3 code#######
public_key, private_key = generate_rsa_keypair()
message_string = b'waggumbura'  # replace with your message
message_int = int.from_bytes(message_string, byteorder='big')
ciphertext_rsa = rsa_encrypt(message_int, public_key)
digits = 10074377926816078563534395930906401411343462297565970868747738770267683637356858818640099418930019938129337369446450601667675891703449310324980946462823399912566697928715283439344300033825699450398786054135320317350132596446475948234506423924071070184159791124928621306921224829912568913311484084469709278906365603950352199485675023628405209758656328490940660221386124988072685028958697267663488145804102836668672259988455938191644477453261026285230978717420162501508731273783830535393231347580781843812911333447584036537275261983911155815552018806104117089121839932075753505690471509756483217743267523284412196295417
decrypted_message = rsa_decrypt(digits, private_key)
m_decrypted = decrypted_message.to_bytes((decrypted_message.bit_length() + 7) // 8, byteorder='big')

print("\nEncrypted message:", ciphertext_rsa)
print("\nDecrypted message:", m_decrypted)
print("\n")
#############