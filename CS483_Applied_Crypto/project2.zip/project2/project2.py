# Nagendra Upadhyay. COSC483 Project 2 Hash Attack

import random
import string
import hashlib
import matplotlib.pyplot as plt
import numpy as np

# Function to calculate the hexadecimal hash of input_text using SHA-1
def calculate_hex_hash(input_text):
    hex_hash_result = hashlib.sha1(input_text.encode()).hexdigest()
    return hex_hash_result

# Function to truncate the hex_hash_value to the specified bits_length
def truncate_hash(hex_hash_value, bits_length):
    # Convert hexadecimal hash value to binary and truncate
    bin_hash_value = bin(int(hex_hash_value, 16))[2:].zfill(160)
    truncated_hash_result = bin_hash_value[:bits_length]
    truncated_hex_result = hex(int(truncated_hash_result, 2))[2:].zfill(bits_length // 4)
    return truncated_hex_result

# Function to find the number of attempts needed to find a collision
def find_collision_attempts(bits_length):
    hash_values_set = set()
    count_attempts = 0

    while True:
        # Generate random text
        random_text_value = ''.join(random.choices(string.ascii_lowercase, k=10))
        # Calculate the truncated hash and check for collision
        hash_digest_result = truncate_hash(calculate_hex_hash(random_text_value), bits_length)

        if hash_digest_result in hash_values_set:
            return count_attempts

        hash_values_set.add(hash_digest_result)
        count_attempts += 1

# Function to find the number of attempts needed to find a preimage
def find_preimage_attempts(target_hash):
    count_attempts = 0

    while True:
        # Generate random text
        random_text_value = ''.join(random.choices(string.ascii_lowercase, k=10))
        # Calculate the truncated hash and check for a preimage
        hash_digest_result = truncate_hash(calculate_hex_hash(random_text_value), len(target_hash) * 4)

        if hash_digest_result == target_hash:
            return count_attempts

        count_attempts += 1

# Function to calculate attack statistics for various bit lengths
def calculate_attack_statistics(bit_lengths_list, sample_size_value):
    # List to store collision and preimage attempt results
    collision_attempts_list = []
    preimage_attempts_list = []

    for bit_length_value in bit_lengths_list:
        # Calculate collision attempts and preimage attempts for each bit length
        collision_attempts_bit = [find_collision_attempts(bit_length_value) for _ in range(sample_size_value)]
        preimage_attempts_bit = [find_preimage_attempts(''.join(random.choices(string.hexdigits.lower(), k=bit_length_value // 4))) for _ in range(sample_size_value)]

        # Append results to respective lists
        collision_attempts_list.append(collision_attempts_bit)
        preimage_attempts_list.append(preimage_attempts_bit)

        # Print statistics for each bit length
        print("Bit Size:", bit_length_value)
        print("Average iterations for the collision attack:", round(np.mean(collision_attempts_bit)))
        print("Average iterations for the preimage attack:", round(np.mean(preimage_attempts_bit)))
        print("Variance for the collision attempts:", round(np.var(collision_attempts_bit)))
        print("Variance for the preimage attempts:", round(np.var(preimage_attempts_bit)))

    return collision_attempts_list, preimage_attempts_list

# Function to plot attack graphs for collision and preimage attacks
def plot_attack_graphs(bit_lengths_list, collision_attempts_list, preimage_attempts_list):
    # Create subplots for collision and preimage attacks
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 10))

    # Plot for collision attack
    ax1.set_title("Collision Attack")
    ax1.set_xlabel("Bit Length")
    ax1.set_ylabel("Iterations (log scale)")
    ax1.set_yscale('log')
    ax1.plot(bit_lengths_list, [1.1774 * (2 ** (bit_length_val / 2)) for bit_length_val in bit_lengths_list], label="Theoretical")
    ax1.plot(bit_lengths_list, [np.mean(attempts) for attempts in collision_attempts_list], label="Experimental Mean")
    ax1.violinplot(collision_attempts_list, positions=bit_lengths_list, showmedians=True)
    ax1.legend()

    # Plot for preimage attack
    ax2.set_title("Preimage Attack")
    ax2.set_xlabel("Bit Length")
    ax2.set_ylabel("Iterations (log scale)")
    ax2.set_yscale('log')
    ax2.plot(bit_lengths_list, [2 ** bit_length_val for bit_length_val in bit_lengths_list], label="Theoretical")
    ax2.plot(bit_lengths_list, [np.mean(attempts) for attempts in preimage_attempts_list], label="Experimental Mean")
    ax2.violinplot(preimage_attempts_list, positions=bit_lengths_list, showmedians=True)
    ax2.legend()

    plt.tight_layout()
    plt.show()

# Function to run the simulation
def run_simulation():
    sample_size_value = 50
    bit_lengths_list = [8, 10, 12, 14, 16, 18, 20, 22]
    collision_attempts_list, preimage_attempts_list = calculate_attack_statistics(bit_lengths_list, sample_size_value)
    plot_attack_graphs(bit_lengths_list, collision_attempts_list, preimage_attempts_list)

if __name__ == '__main__':
    run_simulation()