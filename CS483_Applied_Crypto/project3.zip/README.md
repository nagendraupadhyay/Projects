#MAC Attack(Python)
##How to run the code?
To run the code, use the complier in vscode:
- python3 SHA-1.py "the string you want"
    - e.g. python3 SHA-1.py "Hello World."
- python3 SHA-1.py mac <the mac hex> "the original string you want" "the extended string you want"
    - e.g. python3 SHA-1.py mac f8ac473223 "Hello" "World."

##Probelms
- I ran into some problems with trying to make the fifth example in part 1 to work. When the command (python3 SHA-1.py "Never roll your own crypto!") is ran the "dquote>" starts, but if the same command is ran with '' (python3 SHA-1.py "Never roll your own crypto!"), then it gives me the correct hex number value. Unfortunately, I was not able to figure out a solution to fix it.
- I was also not able to get the correct modified mac hex value, hence was not able to submit it on the pass-off server. Hopefully, I could get some partial credit for part 2.