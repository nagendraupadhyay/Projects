# Nagendra Upadhyay. Cosc483 Project 3 MAC Attack
# The code implements functions for computing hash values using the SHA-1 algorithm and generating a new message with a MAC based on given input arguments from the command line. 
# It processes the input stream, calculates hash values, adds padding, and prints the resulting hash or the new message with its corresponding MAC.
import sys

# Initial hash values
HASHES = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]

# Function to rotate bits left
def rotate_left(n, x, w=32):
    shifted_left = x << n
    shifted_right = x >> (w - n)
    result = (shifted_left | shifted_right) & ((1 << w) - 1)
    return result

# Function to add padding to the input message
def add_padding(stream):
    # Inner function to process the stream
    def process_stream(stream, char_value, pad_len):
        padding_char = chr(char_value) if isinstance(stream, str) else bytes([char_value])
        padding = padding_char * (pad_len - 1)
        return stream + padding

    char_value = 0b10000000
    stream = stream.replace('’', "'") if isinstance(stream, str) else stream.replace(b'\xe2\x80\x99', b"'")

    length_bytes = len(stream)
    length_bits = length_bytes * 8
    pad_len = (56 - length_bytes) % 64 or 64
    stream += chr(char_value) if isinstance(stream, str) else bytes([char_value])
    stream = process_stream(stream, 0, pad_len)
    stream += length_bits.to_bytes(8, 'big')
    return stream

# Function to generate blocks from the input stream
def generate_block(stream):
    blocks = []
    num_blocks = len(stream) // 64
    for i in range(num_blocks):
        block = [int.from_bytes(stream[i * 64 + word * 4: i * 64 + word * 4 + 4], 'big') for word in range(16)]
        blocks.append(block)
    return blocks

# Function to process a block of the message
def process_block(block, hashes):
    mask_value = (1 << 32) - 1
    message_schedule = list(block)
    h0, h1, h2, h3, h4 = list(hashes)

    for i in range(16, 80):
        xor_result = message_schedule[i - 3] ^ message_schedule[i - 8] ^ message_schedule[i - 14] ^ message_schedule[i - 16]
        message_schedule.append(rotate_left(1, xor_result) & mask_value)

    for j in range(80):
        if j <= 19:
            constant = 0x5a827999
            function = (h1 & h2) ^ (~h1 & h3)
        elif j <= 39:
            constant = 0x6ed9eba1
            function = h1 ^ h2 ^ h3
        elif j <= 59:
            constant = 0x8f1bbcdc
            function = (h1 & h2) ^ (h1 & h3) ^ (h2 & h3)
        else:
            constant = 0xca62c1d6
            function = h1 ^ h2 ^ h3

        tmp = ((rotate_left(5, h0) + function + h4 + constant + message_schedule[j]) & mask_value)
        h4, h3, h2, h1, h0 = h3, h2, (rotate_left(30, h1) & mask_value), h0, tmp

    new_hashes = [(h + v) & mask_value for h, v in zip(hashes, [h0, h1, h2, h3, h4])]
    hashes[:] = new_hashes

# Function to calculate the hash of the input stream
def calculate_hash(stream):
    padded_stream = add_padding(stream)
    blocks = generate_block(padded_stream)
    hashes = HASHES[:]

    for block in blocks:
        process_block(block, hashes)
        
    return ''.join(format(val, '08x') for val in hashes)

# Function to calculate the partial hash of the input stream
def calculate_partial_hash(stream, starting_block):
    blocks = generate_block(add_padding(stream))
    blocks_to_process = blocks[starting_block:]

    hashes = HASHES[:]
    for block in blocks_to_process:
        process_block(block, hashes)

    return ''.join(format(val, '08x') for val in hashes)

# Function to generate a new message and MAC
def generate_new_message_and_MAC(key, original_message, original_MAC, netID):
    original_message_hash = calculate_hash(original_message.encode())

    netID_message_hash = calculate_hash(netID.encode())

    print("Original Message Hash Value: " + original_message_hash)
    print("Extended Message Hash Value: " + netID_message_hash)
    new_message = original_message + " " + netID
    new_MAC = calculate_partial_hash(new_message.encode(), len(original_message) // 64)
    return new_message, new_MAC

def main():
    if len(sys.argv) >= 2 and sys.argv[1] == 'mac':
        key = bytes.fromhex(sys.argv[2])
        original_message = sys.argv[3]
        netID_message = sys.argv[4]
        new_message, new_MAC = generate_new_message_and_MAC(key, original_message, "", netID_message)
        print("\nNew Message:")
        print(new_message)
        print("\nNew MAC:")
        print(new_MAC)
    else:
        for arg in sys.argv[slice(1, None)]:
            hex_hash = calculate_hash(arg.encode())
            print("{0}".format(hex_hash))

if __name__ == '__main__':
    main()