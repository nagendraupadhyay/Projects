#Advanced Encryption Standard Project (Python)
##How to run the code?
To run the code, use the commands:
"python3 AES.py > output.txt" for the Python version 3
"python AES.py > output.txt" for the Python older version

When the above command is ran, an output file is created and that file can be compared to the appendixC file.
To do that run the command: "vimdiff output.txt appendix_c.txt"

##Resources used
I used youtube outside of the resources already provided to better understand the concept. 
I also used the "Useful arrays" link to copy the Round Constant, Substitution Box, and Inverse Substitution Box.

##Appendix C (Pass or fail)
I was able to get almost all parts of the appendix C AES-128(Nk=4, Nr=10), AES-192(Nk=6, Nr=12), and AES-256(Nk=8, Nr=14).
The only part that I was not able to get was the Equivalent Inverse Cipher(Decrypt).
